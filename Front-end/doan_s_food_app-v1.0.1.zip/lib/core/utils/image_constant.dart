// ignore_for_file: must_be_immutable
class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

// Detail Profile - Admin images
  static String imgVector = '$imagePath/img_vector.png';

  static String imgVector26x25 = '$imagePath/img_vector_26x25.png';

  static String imgVector47x51 = '$imagePath/img_vector_47x51.png';

  static String imgVector8x10 = '$imagePath/img_vector_8x10.png';

  static String imgVector10x9 = '$imagePath/img_vector_10x9.png';

  static String imgVector12x15 = '$imagePath/img_vector_12x15.png';

  static String imgVector49x45 = '$imagePath/img_vector_49x45.png';

  static String imgVector50x12 = '$imagePath/img_vector_50x12.png';

  static String imgVector48x53 = '$imagePath/img_vector_48x53.png';

  static String imgVector55x47 = '$imagePath/img_vector_55x47.png';

  static String imgVector20x22 = '$imagePath/img_vector_20x22.png';

  static String imgVector22x18 = '$imagePath/img_vector_22x18.png';

  static String imgVector10x10 = '$imagePath/img_vector_10x10.png';

  static String imgVector3x3 = '$imagePath/img_vector_3x3.png';

  static String imgVector1 = '$imagePath/img_vector_1.png';

  static String imgVector56x62 = '$imagePath/img_vector_56x62.png';

  static String imgVector62x58 = '$imagePath/img_vector_62x58.png';

  static String imgVector49x52 = '$imagePath/img_vector_49x52.png';

  static String imgGroup5 = '$imagePath/img_group_5.png';

  static String imgVector2 = '$imagePath/img_vector_2.png';

  static String imgVector11x11 = '$imagePath/img_vector_11x11.png';

  static String imgVector6x6 = '$imagePath/img_vector_6x6.png';

  static String imgVector67x32 = '$imagePath/img_vector_67x32.png';

  static String imgVector5x1 = '$imagePath/img_vector_5x1.png';

  static String imgVector9x7 = '$imagePath/img_vector_9x7.png';

  static String imgVector41x36 = '$imagePath/img_vector_41x36.png';

  static String imgVector16x13 = '$imagePath/img_vector_16x13.png';

  static String img6 = '$imagePath/img_6.png';

  static String imgEdit = '$imagePath/img_edit.svg';

  static String imgVector14x16 = '$imagePath/img_vector_14x16.png';

  static String imgVector8x6 = '$imagePath/img_vector_8x6.png';

  static String imgVector12x10 = '$imagePath/img_vector_12x10.png';

  static String imgVector8x7 = '$imagePath/img_vector_8x7.png';

  static String imgVector4x4 = '$imagePath/img_vector_4x4.png';

  static String imgVector3 = '$imagePath/img_vector_3.png';

  static String imgVector5x45 = '$imagePath/img_vector_5x45.png';

  static String imgVector20x68 = '$imagePath/img_vector_20x68.png';

  static String imgVector3x14 = '$imagePath/img_vector_3x14.png';

  static String imgVector4 = '$imagePath/img_vector_4.png';

  static String imgVector47x47 = '$imagePath/img_vector_47x47.png';

  static String imgVector23x38 = '$imagePath/img_vector_23x38.png';

  static String imgVector11x25 = '$imagePath/img_vector_11x25.png';

  static String imgVector68x60 = '$imagePath/img_vector_68x60.png';

  static String imgVector51x57 = '$imagePath/img_vector_51x57.png';

  static String imgVector53x68 = '$imagePath/img_vector_53x68.png';

  static String imgVector5 = '$imagePath/img_vector_5.png';

  static String imgVector16 = '$imagePath/img_vector_16.png';

  static String imgVector9 = '$imagePath/img_vector_9.png';

  static String imgVector18 = '$imagePath/img_vector_18.png';

  static String imgVector19 = '$imagePath/img_vector_19.png';

  static String imgIconNotification = '$imagePath/img_icon_notification.png';

  static String imgVector62x70 = '$imagePath/img_vector_62x70.png';

  static String imgVector45x56 = '$imagePath/img_vector_45x56.png';

  static String imgVector17x50 = '$imagePath/img_vector_17x50.png';

  static String imgVector2x10 = '$imagePath/img_vector_2x10.png';

  static String imgVector25x61 = '$imagePath/img_vector_25x61.png';

  static String imgVector10x69 = '$imagePath/img_vector_10x69.png';

  static String imgVector31x53 = '$imagePath/img_vector_31x53.png';

  static String imgVector6 = '$imagePath/img_vector_6.png';

  static String imgVector7 = '$imagePath/img_vector_7.png';

  static String imgVector5x5 = '$imagePath/img_vector_5x5.png';

  static String imgVector8 = '$imagePath/img_vector_8.png';

  static String imgVector8x11 = '$imagePath/img_vector_8x11.png';

  static String imgVector8x9 = '$imagePath/img_vector_8x9.png';

  static String imgVector60x74 = '$imagePath/img_vector_60x74.png';

  static String imgVector1x1 = '$imagePath/img_vector_1x1.png';

  static String imgVector2x2 = '$imagePath/img_vector_2x2.png';

  static String imgVector12 = '$imagePath/img_vector_12.png';

  static String imgVector2x1 = '$imagePath/img_vector_2x1.png';

  static String imgVector10 = '$imagePath/img_vector_10.png';

  static String imgVector11 = '$imagePath/img_vector_11.png';

  static String imgVector1x2 = '$imagePath/img_vector_1x2.png';

  static String imgVector13 = '$imagePath/img_vector_13.png';

  static String imgVector14 = '$imagePath/img_vector_14.png';

  static String imgVector18x27 = '$imagePath/img_vector_18x27.png';

  static String imgVector15 = '$imagePath/img_vector_15.png';

  static String imgVector17 = '$imagePath/img_vector_17.png';

  static String imgVector11x8 = '$imagePath/img_vector_11x8.png';

  static String imgVector2x13 = '$imagePath/img_vector_2x13.png';

  static String imgVector1x5 = '$imagePath/img_vector_1x5.png';

  static String imgVector44x67 = '$imagePath/img_vector_44x67.png';

  static String imgUser = '$imagePath/img_user.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
