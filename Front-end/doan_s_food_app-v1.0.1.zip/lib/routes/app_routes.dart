import 'package:flutter/material.dart';
import '../core/app_export.dart';
import '../presentation/detail_profile_admin_screen/detail_profile_admin_screen.dart'; // ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class AppRoutes {
  static const String detailProfileAdminScreen = '/detail_profile_admin_screen';

  static const String initialRoute = '/initialRoute';

  static Map<String, WidgetBuilder> routes = {
    detailProfileAdminScreen: (context) => DetailProfileAdminScreen(),
    initialRoute: (context) => DetailProfileAdminScreen()
  };
}
